/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package team1Project;

import java.awt.Dimension;
import javax.swing.JFrame;

/**
 *
 * @author Kincaid Wedgeworth
 */
public class HistoryCanvas 
{
    private JFrame frame;
    
    HistoryCanvas(String name, String[] type, int[] x, int[] y, int[] height, int[] width, int[] stroke, int[] diameter, int[] red, int[] green, int[] blue)
    {
        frame = new JFrame(name);
        HistoryPainter load = new HistoryPainter(type.length, type, x, y, height, width, stroke, diameter, red, green, blue);
        
        // These set the size to an unchangeable 690x420
        frame.setPreferredSize(new Dimension(690, 420));
        frame.setMinimumSize(new Dimension(690, 420));
        frame.setMaximumSize(new Dimension(690, 420));
        frame.setResizable(false);
        
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.getContentPane().add(load);
        frame.setVisible(false);
    }
    
    public void visibility(Boolean b) {
        frame.setVisible(b);
    }
}
