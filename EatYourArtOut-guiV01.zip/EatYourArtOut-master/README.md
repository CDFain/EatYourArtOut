# EatYourArtOut
Team 1's Eat Your Art Out project for CS 321, Fall 2019

This is interesting
