/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package team1Project;

import java.util.*;
import java.awt.*;
/**
 * This is still a WIP and possibly wont be needed
 * @author CDFain
 */
public class Colors {
    private Color colors[] = new Color[11];
    private int amount; 
     
    
    public static void main(String args[]) {
        Color x;
        
        x = Color.YELLOW;
        System.out.print(x);
    }
    
    
}
