/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package team1Project;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Line2D;
import javax.swing.JPanel;

/**
 *
 * @author Kincaid Wedgeworth
 */
public class HistoryPainter extends JPanel
{
    private int size;
    
    private String[] type; // type is used to save if the current instruction is a line or dot
    private int[] x, y, height, width, diameter, stroke, red, green, blue;
    /*
    x- the x postion of the drawing 
    y- the y postion of the drawing
    
    height- the height of the line in particular
    width- the width of the line in particular
    storke- I am assuming this is line orientation, as I only know it is used for the stroke
    
    diameter- the diameter of the dots
    
    red- the red value for coloring the drawing
    green- the green value for coloring the drawing
    blue- the blue value for coloring the drawing
    */
    
    HistoryPainter(int sizeNew, String[] typeNew, int[] xNew, int[] yNew, int[] heightNew, int[] widthNew, int[] strokeNew, int[] diameterNew, int[] redNew, int[] greenNew, int[] blueNew)
    {
        size = sizeNew;
        
        type = new String[size];
        
        x = new int[size];
        y = new int[size];
        height = new int[size];
        width = new int[size];
        stroke = new int[size];
        
        diameter = new int[size];
        
        red = new int[size];
        green = new int[size];
        blue = new int[size];
        
        type = typeNew.clone();
        
        x = x.clone();
        y = y.clone();
        height = height.clone();
        width = width.clone();
        stroke = stroke.clone();
        
        diameter = diameter.clone();
        
        red = red.clone();
        green = green.clone();
        blue = blue.clone();
    }
    
    public void paintComponent(Graphics g)
    {
        Graphics2D g2 = (Graphics2D) g;
        setBackground(Color.WHITE);
        
        for (int i = 0; i < size; i++)
        {
            if (type[i].equalsIgnoreCase("dot"))
            {
                g.setColor(new Color(red[i], green[i], blue[i]));
                
                g.fillOval(x[i], y[i], diameter[i], diameter[i]);
            }
            if (type[i].equalsIgnoreCase("line"))
            {
                g.setColor(new Color(red[i], green[i], blue[i]));
                // These draw the line
                g2.setStroke(new BasicStroke(stroke[i]));
                g2.draw(new Line2D.Float(x[i], y[i], height[i], width[i]));
            }
        }
    }
}
