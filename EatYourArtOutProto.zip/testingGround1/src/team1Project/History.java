/*
 * Group Project "Eat Your Art Out" for CS 321
 * Fall Semester 2019
 */
package team1Project;

import java.awt.*;
import java.awt.geom.Line2D;
import javax.swing.*;
import java.util.*;
import java.io.*;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

/**
 * This is the class that saves the current picture that was drawn, by 
 * saving the drawing instructions to a text document in the art source
 * package with a couple of functions-- then has a function to read from
 * that file and redraws the picture from the instructions
 * 
 * @author Kincaid Wedgeworth
 */
public class History extends JPanel
{
    // These are to store the important vairables to then save to the file
    private String[] type; // type is used to save if the current instruction is a line or dot
    private int[] x, y, height, width, diameter, stroke, red, green, blue;
    /*
    x- the x postion of the drawing 
    y- the y postion of the drawing
    
    height- the height of the line in particular
    width- the width of the line in particular
    storke- I am assuming this is line orientation, as I only know it is used for the stroke
    
    diameter- the diameter of the dots
    
    red- the red value for coloring the drawing
    green- the green value for coloring the drawing
    blue- the blue value for coloring the drawing
    */
    
    // This is for the new loaded picture to draw on
    //private static JFrame frame = new JFrame("Canvas");
    
    public String getThing(int order)
    {
        return type[order];
    }
    
    
    /**
     * This is to actually save the picture information to the file, so it 
     * creates the file if it doesn't exist then using the variables above
     * saves all of the variables to that file
     * 
     * @param name is the file name the user wants to use
     * @param total is the total lines and dots that were used
     */
    public void savePic(String name, int total)
    {
        // This try catch is for checking for the file path issues
        try
        {
            // The file path is created with with the users name input and in the art package
            File path = new File("src" + File.separator + "art" + File.separator + name + ".txt");
            // If file doesn't exists it creates that file to write to
            if (!path.exists())
            {
                path.createNewFile();
            } 
            else
            {
                path.delete();
                path.createNewFile();
            }
            
            // This creates the writer and buffered writer so the file can be writen to
            FileWriter picInfo = new FileWriter(path, true);
            BufferedWriter buffInfo = new BufferedWriter(picInfo);
            
            
            
            // This loop is to go through the entirerity of the type array and write accordingly 
            for (int i = 0; i < total; i++)
            {
                // If the type is a dot it writes all of the important info for the dot
                System.out.println(i + " in save: " + type[i]);
                if (type[i].equalsIgnoreCase("dot"))
                {
                    buffInfo.write(type[i] + "\n");
                
                    buffInfo.write(x[i] + "\n");
                    buffInfo.write(y[i] + "\n");
                    buffInfo.write(diameter[i] + "\n");
                    
                    buffInfo.write(red[i] + "\n");
                    buffInfo.write(green[i] + "\n");
                    buffInfo.write(blue[i] + "\n");
                    
                    buffInfo.flush(); // This flush is so it writes all of this at once and not a block
                }
                
                // If the type is a line it writes all of the important info for the line
                if (type[i].equalsIgnoreCase("line"))
                {
                    buffInfo.write(type[i] + "\n");

                    buffInfo.write(stroke[i] + "\n");
                    buffInfo.write(x[i] + "\n");
                    buffInfo.write(y[i] + "\n");
                    buffInfo.write(height[i] + "\n");
                    buffInfo.write(width[i] + "\n");

                    buffInfo.write(red[i] + "\n");
                    buffInfo.write(green[i] + "\n");
                    buffInfo.write(blue[i] + "\n");
                    
                    buffInfo.flush(); // This flush is so it writes all of this at once and not a block
                }
                
            }
            buffInfo.close(); // Closes the writer
            
        }
        catch(IOException e)
        {
            System.out.println("Error_file: " + e);
        }
        
    }
    
    /**
     * IMPORTANT: you need to call this before you start saving info
     * 
     * The savePicSetup is to initalize all of the arrays so it doesn't 
     * cause an error to occur by setting the arrays size to the input
     * 
     * @param size is the amount of lines and dots all together and the size of all of the arrays
     */
    public void savePicSetup(int size)
    {
        type = new String[size];
        
        x = new int[size];
        y = new int[size];
        height = new int[size];
        width = new int[size];
        stroke = new int[size];
        
        diameter = new int[size];
        
        red = new int[size];
        green = new int[size];
        blue = new int[size];
    }
    
    /**
     * This is to save the important information to draw a line into the arrays.
     * Call this after a line is drawn (IMPORTANT: see savePicSetup)
     * 
     * @param order is the order of drawing and is the array positions everything is saved to, usually should be a count in a loop
     * @param strokeNew is the new input for the stroke variable
     * @param xNew is the new input for the x variable
     * @param yNew is the new input for the y variable
     * @param heightNew is the new input for the height variable
     * @param widthNew is the new input for the width variable
     * @param redNew is the new input for the red variable
     * @param greenNew is the new input for the green variable
     * @param blueNew is the new input for the blue variable
     */
    public void saveLineInfo(int order, int strokeNew, int xNew, int yNew, int heightNew, int widthNew, int redNew, int greenNew, int blueNew)
    {   
        type[order] = "line"; // Sets type to line so the program knows everything in that order is a line 
        
        stroke[order] = strokeNew;
        x[order] = xNew;
        y[order] = yNew;
        height[order] = heightNew;
        width[order] = widthNew;
        
        red[order] = redNew;
        green[order] = greenNew;
        blue[order] = blueNew;
    }
    
    /**
     * This is to save the important information to draw a line into the arrays.
     * Call this after a dot is drawn (IMPORTANT: see savePicSetup)
     * 
     * @param order is the order of drawing and is the array positions everything is saved to, usually should be a count in a loop
     * @param xNew is the new input for the x variable
     * @param yNew is the new input for the y variable
     * @param diameterNew is the new input for the diameter variable
     * @param redNew is the new input for the red variable
     * @param greenNew is the new input for the green variable
     * @param blueNew is the new input for the blue variable
     */
    public void saveDotInfo(int order, int xNew, int yNew, int diameterNew, int redNew, int greenNew, int blueNew)
    {   
        type[order] = "dot"; // Sets type to dot so the program knows everything in that order is a dot 
        
        x[order] = xNew;
        y[order] = yNew;
        diameter[order] = diameterNew;
        
        red[order] = redNew;
        green[order] = greenNew;
        blue[order] = blueNew;
    }
    
    /**
     * This is the function that loads in the information from a file then prints
     * it out to a new canvas for the user
     * 
     * @param name is the file location
     */
    public void loadPic(String name)
    {
        int count = 0; // count variable to move through the arrays
        
        // Try catch to see if the file name inputed exists
        try
        {
            String line = null; // This is for the read line to see if the file is done
                    
            // Creates the file path that is checked by the try catch
            File path = new File("src" + File.separator + "art" + File.separator + name + ".txt");
            
            // Creates a BufferdReader from a FileReader so it can read in from the file
            FileReader picInfo = new FileReader(path);
            BufferedReader buffInfo = new BufferedReader(picInfo);

            this.clear(); // Clears the arrays so nothing stays there on accident
            
            int size = 0;
            String trash = null;
            
            while ((line = buffInfo.readLine()) != null)
            {
                if (line.equalsIgnoreCase("dot"))
                {
                    size++;
                    
                    trash = buffInfo.readLine();
                    trash = buffInfo.readLine();
                    trash = buffInfo.readLine();
                    
                    trash = buffInfo.readLine();
                    trash = buffInfo.readLine();
                    trash = buffInfo.readLine();
                }
                
                if (line.equalsIgnoreCase("line"))
                {
                    size++;
                    
                    trash = buffInfo.readLine();
                    trash = buffInfo.readLine();
                    trash = buffInfo.readLine();
                    trash = buffInfo.readLine();
                    trash = buffInfo.readLine();
                    
                    trash = buffInfo.readLine();
                    trash = buffInfo.readLine();
                    trash = buffInfo.readLine();
                }
            }
            
            buffInfo.close();
            
            this.savePicSetup(size);
            
            picInfo = new FileReader(path);
            buffInfo = new BufferedReader(picInfo);
            
            // This loop runs as long as the file has a line to read in
            while ((line = buffInfo.readLine()) != null)
            {
                // If the first thing read in is a dot it takes info for a dot
                if (line.equalsIgnoreCase("dot"))
                {
                    // Checks to see if the line read is an integer, and catches if not
                    try
                    {
                        type[count] = line;
                        
                        x[count] = Integer.parseInt(buffInfo.readLine());
                        y[count] = Integer.parseInt(buffInfo.readLine());
                        diameter[count] = Integer.parseInt(buffInfo.readLine());

                        red[count] = Integer.parseInt(buffInfo.readLine());
                        green[count] = Integer.parseInt(buffInfo.readLine());
                        blue[count] = Integer.parseInt(buffInfo.readLine());
                        
                        // Could be printed here or later
                    }
                    catch (NumberFormatException e)
                    {
                        System.out.println("Conversion_error: " + e);
                    }
                }
                // If the first thing read in is a line it takes info for a line
                else if (line.equalsIgnoreCase("line"))
                {
                    // Checks to see if the line read is an integer, and catches if not
                    try
                    {
                        type[count] = line;
                        
                        stroke[count] = Integer.parseInt(buffInfo.readLine());
                        x[count] = Integer.parseInt(buffInfo.readLine());
                        y[count] = Integer.parseInt(buffInfo.readLine());
                        height[count] = Integer.parseInt(buffInfo.readLine());
                        width[count] = Integer.parseInt(buffInfo.readLine());

                        red[count] = Integer.parseInt(buffInfo.readLine());
                        green[count] = Integer.parseInt(buffInfo.readLine());
                        blue[count] = Integer.parseInt(buffInfo.readLine());
                        
                        // Could be printed here or later
                    }
                    catch (NumberFormatException e)
                    {
                        System.out.println("Conversion_error: " + e);
                    }
                }
                
                count++; // Increase count to move through arrays
            }
            
            HistoryCanvas load = new HistoryCanvas(name, type, x, y, height, width, stroke, diameter, red, green, blue);
            load.visibility(true);
            
            buffInfo.close(); // Closes the reader 
        }
        catch(IOException e)
        {
            System.out.println("Error_file: " + e + " does not exist");
        }
    }
    
    /**
     * This clears all the variable arrays so they can be reused
     */
    public void clear()
    {   
        type = null;
        
        x = null;
        y = null;
        height = null;
        width = null;
        diameter = null;
        stroke = null;

        red = null;
        green = null;
        blue = null;
    }
}
